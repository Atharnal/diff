8bit Adventurer
Lime (movie : Frantzz)
OBJ. Atharnal
本体 : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=444&event=116
推定レベル：

ズレ チェック
 - キー音分割によるズレあり。
 - 23, 95小節の5Nキーを分割し、譜面上はZZに変更している。
 - 88小節の0pキーを分割し、譜面上はZZに変更している。
 - 分割キー音は同封されています。



32番目の差分。
よろしくお願いいたします。

-Atharnal (discord : Atharnal#2977)