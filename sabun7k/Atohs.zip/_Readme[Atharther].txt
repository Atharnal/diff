Atohs
Music: Ice / Movie: Sand Suna
OBJ. Atharnal
本体 : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=429&event=142
推定レベル：St4

ズレ チェック :  atohs_base.bms とのズレなし


38番目の差分。
よろしくお願いいたします。

-Atharnal (discord : Atharnal#2977)
-Twitter : https://twitter.com/atharnal